from sympy.geometry import*
from problem1 import*
from problem2 import*
from problem3 import*

def main():
    #begin program1
    p1 = problem1()
    #p1.get_value("v1")
    #p1.get_all()
    #boot up p1
    while p1.print_menu():
        #input("Enter anything to continue to the menu. ")
        pass


    print("Exiting program...")

if __name__ == "__main__":
    main()
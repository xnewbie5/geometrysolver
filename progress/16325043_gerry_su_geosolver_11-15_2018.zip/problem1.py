from sympy.geometry import*
import math

class problem1:
    def __init__(self):
        self.List = dict() #list of known variables
        self.i1 = None #hidden from the user
        self.i2 = None
        self.c1 = None
        self.c2 = None
        self.a1_rads = None
        self.a2_rads = None
        self.a3_rads = None
        self.List =	{
            "v1": None,
            "v2": None,
            "v3": None,
            "a1": None, #remember, do math in radians
            "a2": None,
            "a3": None,
            "e1": None,
            "e2": None,
            "e3": None,
            "radius": None,
            "center": None                
        }

    def get_all(self):
        print (self.List)
        return self.List

    def print_menu(self):
        #print out the list in the dictionary and prompt for editing
        j = 1
        for i in self.List:
            print(j,i,"=",self.List[i])
            j+=1
        print(j,"Submit")
        j+=1
        print(j, "Print additional variables")
        j+=1
        print(j, "Clear")
        j+=1
        print(j,"Quit")
        uInput = input("Select an option or choose a value to edit: ")
        #Keep main menu loop going by returning True
        if(self.perform_Operation(uInput)==True):
            return True
        else:
            return False

    def testFloat(self, x):
        try:
            return float(x)
        except ValueError:
            print("Not a float")
            return False

    def perform_Operation(self, operation):
        if operation.lower() in {"1","v1"}:
            uInput = input("Input value for VERTEX v1 X: ")
            f_uInput = self.testFloat(uInput)
            uInput = input("Input value for VERTEX v1 Y: ")
            f2_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float and type(f2_uInput)==float):
                self.set_vertex("v1", f_uInput, f2_uInput)
                print("Successfully edited v1")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"2","v2"}:
            uInput = input("Input value for VERTEX v2 X: ")
            f_uInput = self.testFloat(uInput)
            uInput = input("Input value for VERTEX v2 Y: ")
            f2_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float and type(f2_uInput)==float):
                self.set_vertex("v2", f_uInput, f2_uInput)
                print("Successfully edited v2")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"3","v3"}:
            uInput = input("Input value for VERTEX v3 X: ")
            f_uInput = self.testFloat(uInput)
            uInput = input("Input value for VERTEX v3 Y: ")
            f2_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float and type(f2_uInput)==float):
                self.set_vertex("v3", f_uInput, f2_uInput)
                print("Successfully edited v3")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"4","a1"}:
            uInput = input("Input value (angle in degrees) for a1: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("a1", f_uInput)
                print("Successfully edited a1")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"5","a2"}:
            uInput = input("Input value (angle in degrees) for a2: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("a2", f_uInput)
                print("Successfully edited a2")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"6","a3"}:
            uInput = input("Input value (angle in degrees) for a3: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("a3", f_uInput)
                print("Successfully edited a3")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"7","e1"}:
            uInput = input("Input value (edge length) for e1: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("e1", f_uInput)
                print("Successfully edited e1")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"8","e2"}:
            uInput = input("Input value (edge length) for e2: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("e2", f_uInput)
                print("Successfully edited e2")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"9","e3"}:
            uInput = input("Input value (edge length) for e3: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("e3", f_uInput)
                print("Successfully edited e3")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"10","radius"}:
            uInput = input("Input value for radius: ")
            f_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float):
                self.set_value("radius", f_uInput)
                print("Successfully edited radius")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"11","center"}:
            uInput = input("Input value for CENTER of CIRCLE X: ")
            f_uInput = self.testFloat(uInput)
            uInput = input("Input value for CENTER of CIRCLE Y: ")
            f2_uInput = self.testFloat(uInput)
            if(type(f_uInput)==float and type(f2_uInput)==float):
                self.set_vertex("center", f_uInput, f2_uInput)
                print("Successfully edited CENTER of CIRCLE")
            else:
                print("Invalid type entered")
        elif operation.lower() in {"12", "submit"}:
            self.solve_looping()
        elif operation.lower() in {"13"}:
            self.print_extra_variables()
        elif operation.lower() in {"14", "clear"}:
            self.set_Example()
        elif operation.lower() in ("15", "quit", "q"):
            return False
        return True #leave switch case

    def get_value(self, name):
        if name in self.List:
            print (self.List.get(name)) #difference b/w direct access and get() is the default value if not found. Default is None
            return self.List.get(name)

    def set_Example(self):
        for x in self.List:
            self.List[x] = None

    def print_extra_variables(self):
        print("i1: ", self.i1)
        print("i2: ", self.i2)
        print("c1: ", self.c1)
        print("c2: ", self.c2)
        input("Enter anything to continue...")

    #ASSUME THE CENTER OF CIRCLE IS A VERTEX
    def set_vertex(self, name, x, y):
        if (name == "v1" or name == "v2" or name == "v3" or name == "center"):
            if name in self.List: #checks if the String name is in the list
                self.List[name] = Point(x,y, evaluate=False) #keep the user input before evaluation
    
    def set_value(self, name, value):
        if (name != "v1" and name != "v2" and name != "v3" and name != "center"):
            if name in self.List:
                if (name == "a1"):
                    self.a1_rads = math.radians(value)
                    self.List[name] = value
                elif (name == "a2"):
                    self.a2_rads = math.radians(value)
                    self.List[name] = value
                elif (name == "a3"):
                    self.a3_rads = math.radians(value)
                    self.List[name] = value
                else:
                    self.List[name] = value

    def create_triangle(self):
        #check if we can create a triangle (3 vertices only)
        return

    def solve_looping(self):
    #begin solve looping, solve returns false if there are no more things left to solve
    #so only break out if result and result2 return true.
    #everytime something is solved once, false statement is returned.
        while True:
            result = self.solve_Triangle()
            result2 = self.solve_Circle()
            if(result and result2):
                input("Done! No more things to solve. Enter anything to continue... ")
                break

    #attempt to solve triangle
    def solve_Triangle(self):
        #put in a bunch of if cases using temporary variables
        tV1 = self.List["v1"]
        tV2 = self.List["v2"]
        tV3 = self.List["v3"]
        tA1 = self.List["a1"]
        tA2 = self.List["a2"]
        tA3 = self.List["a3"]
        tE1 = self.List["e1"]
        tE2 = self.List["e2"]
        tE3 = self.List["e3"]
        tI1 = self.i1
        tI2 = self.i2
        tC1 = self.c1
        tC2 = self.c2
        #check for current errors
        #check if the angles add up
        #https://docs.python.org/3/library/exceptions.html#exception-hierarchy
        #handles an arbitrarily number of arguments to be passed to the constructor.
        try:
            if(tA1 != None and tA2 != None and tA3 != None):
                tSum = tA1+tA2+tA3
                if(tSum != 180):
                    raise ArithmeticError("Warning: Triangle MIGHT NOT add up to 180 degrees.") 
        except ArithmeticError as err:
            print(err.args)
            return True

        #Using my geometry knowledge.. Solve for all unknowns!
        if(tV1 == None):
            pass
        if(tV2 == None):
            pass
        if(tV3 == None):
            pass
        if(tA1 == None):
            if( tA2 != None and tA3 != None):
                #use the other two angles, requires a2, a3
                tA1 = 180-tA2-tA3
                self.List["a1"] = tA1
                return False
            elif(tE3 != None and tA2 != None and tE1 != None):
                #sas triangle using e3, a2, e1.
                tTri = Triangle(sas=(tE3,tA2,tE1))
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE2 = self.toFloat(tTri.sides[1].length)
                self.List["a1"] = round(tA1,2)
                self.List["a3"] = round(tA3,2)
                self.List["e2"] = round(tE2,0)
                return False
            elif(tE2 != None and tA3 != None and tE1 != None):
                #sas triangle using e2, a3, e1.
                tTri = Triangle(sas=(tE2,tA3,tE1))
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE3 = self.toFloat(tTri.sides[1].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["e3"] = round(tE3,0)
                return False
            elif(isinstance(tV1, Point2D) and isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                #all three vertices are established.
                tTri = Triangle(tV1,tV2,tV3)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[0]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                tE2 = self.toFloat(tTri.sides[0].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                return False

        if(tA2 == None):
            if( tA1 != None and tA3 != None):
                #use the other two angles, requires a1, a3
                tA2 = 180-tA1-tA3
                self.List["a2"] = tA2
                return False
            elif(tE3 != None and tA1 != None and tE2 != None):
                #sas triangle using e3, a1, e2.
                tTri = Triangle(sas=(tE3,tA1,tE2))
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                return False
            elif(tE2 != None and tA3 != None and tE1 != None):
                #sas triangle using e2, a3, e1.
                tTri = Triangle(sas=(tE2,tA3,tE1))
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE3 = self.toFloat(tTri.sides[1].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["e3"] = round(tE3,0)
                return False
            elif(isinstance(tV1, Point2D) and isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                #all three vertices are established.
                tTri = Triangle(tV1,tV2,tV3)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[0]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                tE2 = self.toFloat(tTri.sides[0].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                return False
        if(tA3 == None):
            if( tA1 != None and tA2 != None):
                #use the other two angles, requires a1, a2
                tA3 = 180-tA1-tA2
                self.List["a3"] = tA3
                return False
            elif(tE3 != None and tA1 != None and tE2 != None):
                #sas triangle using e3, a1, e2.
                tTri = Triangle(sas=(tE3,tA1,tE2))
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                return False
            elif(tE3 != None and tA2 != None and tE1 != None):
                #sas triangle using e3, a2, e1.
                tTri = Triangle(sas=(tE3,tA2,tE1))
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE2 = self.toFloat(tTri.sides[1].length)
                self.List["a1"] = round(tA1,2)
                self.List["a3"] = round(tA3,2)
                self.List["e2"] = round(tE2,0)
                return False
            elif(isinstance(tV1, Point2D) and isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                #all three vertices are established.
                tTri = Triangle(tV1,tV2,tV3)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[0]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                tE2 = self.toFloat(tTri.sides[0].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                return False
        if(tE1 == None):
            #asa triangle a2, e3, a1
            if(tA2 != None and tE3 != None and tA1 != None):
                tTri = Triangle(asa=(tA2,tE3,tA1))
                tE2 = self.toFloat(tTri.sides[1].length)
                tE1 = self.toFloat(tTri.sides[2].length)
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                self.List["e2"] = round(tE2,0)
                self.List["e1"] = round(tE1,0)
                self.List["a3"] = round(tA3,2)
                return False
            #asa triangle a1, e2, a3
            if(tA1 != None and tE2 != None and tA3 != None):
                tTri = Triangle(asa=(tA1,tE2,tA3))
                tE3 = self.toFloat(tTri.sides[2].length)
                tE1 = self.toFloat(tTri.sides[1].length)
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                self.List["e3"] = round(tE3,0)
                self.List["e1"] = round(tE1,0)
                self.List["a2"] = round(tA2,2)
                return False
            #sas triangle e3, a1, e2
            if(tE2 != None and tA1 != None and tE2 != None):
                tTri = Triangle(sas=(tE3,tA1,tE2))
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                return False
            #vertices v2 and v3 are established
            if(isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                tE1 = self.toFloat(tV2.distance(tV3))
                self.List["e1"] = round(tE1,2)
                return False
            elif(isinstance(tV1, Point2D) and isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                #all three vertices are established.
                tTri = Triangle(tV1,tV2,tV3)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[0]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                tE2 = self.toFloat(tTri.sides[0].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                return False

        if(tE2 == None):
            #sas triangle e3, a2, e1
            if(tE3 != None and tA2 != None and tE1 != None):
                #sas triangle using e3, a2, e1.
                tTri = Triangle(sas=(tE3,tA2,tE1))
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE2 = self.toFloat(tTri.sides[1].length)
                self.List["a1"] = round(tA1,2)
                self.List["a3"] = round(tA3,2)
                self.List["e2"] = round(tE2,0)
                return False
            #asa triangle a2, e1, a3
            elif(tA2 != None and tE1 != None and tA3 != None):
                tTri = Triangle(asa=(tA2,tE1,tA3))
                tE2 = self.toFloat(tTri.sides[1].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                self.List["a1"] = round(tA1,2)
                return False
            #asa triangle a2, e3, a1
            elif(tA2 != None and tE3 != None and tA1 != None):
                tTri = Triangle(asa=(tA2,tE3,tA1))
                tE2 = self.toFloat(tTri.sides[1].length)
                tE1 = self.toFloat(tTri.sides[2].length)
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                self.List["e2"] = round(tE2,0)
                self.List["e1"] = round(tE1,0)
                self.List["a3"] = round(tA3,2)
                return False
            #vertices v1 and v3 are established
            if(isinstance(tV1,Point2D) and isinstance(tV3,Point2D)):
                tE2 = self.toFloat(tV1.distance(tV3))
                self.List["e2"] = round(tE1,2)
                return False
            elif(isinstance(tV1, Point2D) and isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                #all three vertices are established.
                tTri = Triangle(tV1,tV2,tV3)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[0]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                tE2 = self.toFloat(tTri.sides[0].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                return False
        if(tE3 == None):
            #asa triangle a1, e2, a3
            if(tA1 != None and tE2 != None and tA3 != None):
                tTri = Triangle(asa=(tA1,tE2,tA3))
                tE3 = self.toFloat(tTri.sides[2].length)
                tE1 = self.toFloat(tTri.sides[1].length)
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                self.List["e3"] = round(tE3,0)
                self.List["e1"] = round(tE1,0)
                self.List["a2"] = round(tA2,2)
                return False
            #asa triangle a2, e1, a3
            elif(tA2 != None and tE1 != None and tA3 != None):
                tTri = Triangle(asa=(tA2,tE1,tA3))
                tE2 = self.toFloat(tTri.sides[1].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                self.List["a1"] = round(tA1,2)
                return False
            #sas triangle e2, a3, e1
            elif(tE2 != None and tA3 != None and tE1 != None):
                #sas triangle using e2, a3, e1.
                tTri = Triangle(sas=(tE2,tA3,tE1))
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE3 = self.toFloat(tTri.sides[1].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["e3"] = round(tE3,0)
                return False
            #Vertices v1, v2 are established
            if(isinstance(tV1,Point2D) and isinstance(tV2,Point2D)):
                tE3 = self.toFloat(tV1.distance(tV2))
                self.List["e3"] = round(tE3,2)
                return False
            elif(isinstance(tV1, Point2D) and isinstance(tV2,Point2D) and isinstance(tV3,Point2D)):
                #all three vertices are established.
                tTri = Triangle(tV1,tV2,tV3)
                tA1 = self.toDegrees(tTri.angles[tTri.vertices[0]])
                tA2 = self.toDegrees(tTri.angles[tTri.vertices[2]])
                tA3 = self.toDegrees(tTri.angles[tTri.vertices[1]])
                tE1 = self.toFloat(tTri.sides[1].length)
                tE2 = self.toFloat(tTri.sides[0].length)
                tE3 = self.toFloat(tTri.sides[2].length)
                self.List["a1"] = round(tA1,2)
                self.List["a2"] = round(tA2,2)
                self.List["a3"] = round(tA3,2)
                self.List["e1"] = round(tE1,0)
                self.List["e2"] = round(tE2,0)
                self.List["e3"] = round(tE3,0)
                return False

        return True #return True if no more things to solve

    #attempt to solve circle
    def solve_Circle(self):
        if((self.List["radius"] != None) and (self.List["center"] != None)):
            tempCircle = Circle(self.List["center"], self.List["radius"])
            print("TempCircle Created")
        #does it intersect a line segment twice?
        if():
            pass
        return True

    def toDegrees(self, x):
        return float(x*180/math.pi)

    def toFloat(self, x):
        return float(x)


        
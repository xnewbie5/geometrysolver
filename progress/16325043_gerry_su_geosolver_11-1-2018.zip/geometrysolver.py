from sympy.geometry import*
from problem1 import*
from problem2 import*
from problem3 import*

def main():
    p1 = problem1()
    p1.get_value("v1")
    p1.get_all()

if __name__ == "__main__":
    main()